/*
SQLyog Community v12.4.3 (32 bit)
MySQL - 10.1.10-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `tblcar` (`id`, `model`, `make`, `preview`, `description`, `price`) values('1','Primera','Nissan','/img/car1.png',NULL,'23320');
insert into `tblcar` (`id`, `model`, `make`, `preview`, `description`, `price`) values('2','Cefiro','Nissan','/img/car2.png',NULL,'38165');
insert into `tblcar` (`id`, `model`, `make`, `preview`, `description`, `price`) values('3','Camry','Toyota','/img/car3.png',NULL,'24170');
insert into `tblcar` (`id`, `model`, `make`, `preview`, `description`, `price`) values('4','Century','Toyota','/img/car4.png',NULL,'28730');
insert into `tblcar` (`id`, `model`, `make`, `preview`, `description`, `price`) values('5','Sigma','Mitsubishi','/img/car5.png',NULL,'54120');
